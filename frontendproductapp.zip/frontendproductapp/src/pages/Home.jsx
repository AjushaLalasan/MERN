import React from "react";

function Home() {
  return (
    <div className="flex flex-col justify-center items-center min-h-screen bg-gray-100">
      <h1 className="text-4xl font-bold text-gray-800 mb-4">
        Welcome to MYSTORE
      </h1>
      <p className="text-lg text-gray-600">
        Explore our products and enjoy seamless shopping experience!
      </p>
    </div>
  );
}

export default Home;
